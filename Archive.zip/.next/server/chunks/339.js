"use strict";
exports.id = 339;
exports.ids = [339];
exports.modules = {

/***/ 6339:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ home)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/meta.jsx
var meta = __webpack_require__(5509);
// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
// EXTERNAL MODULE: external "merkletreejs"
var external_merkletreejs_ = __webpack_require__(3084);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./data/abi/verseshoe.json
var verseshoe = __webpack_require__(4084);
// EXTERNAL MODULE: ./data/wallets/whitelist.json
var whitelist = __webpack_require__(4106);
// EXTERNAL MODULE: ./redux/counterSlice.js
var counterSlice = __webpack_require__(4954);
;// CONCATENATED MODULE: ./components/mint.jsx








const keccak256 = __webpack_require__(7981);
const Mint = ({ onNotify  })=>{
    const { signerAddress  } = (0,external_react_redux_.useSelector)((state)=>state.counter);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const contractAddress = "0x65A3851aBcE850Dad4805fBA51F3A3A313CA04E0";
    const [maxSupply, setMaxSupply] = (0,external_react_.useState)(2888);
    const [totalSupply, setTotalSupply] = (0,external_react_.useState)(686);
    const [mintStatus, setMintStatus] = (0,external_react_.useState)(0);
    const [maxMintWhitelist, setMaxMintWhitelist] = (0,external_react_.useState)(0);
    const [mintPriceWhitelist, setMintPriceWhitelist] = (0,external_react_.useState)(0);
    const [quantity, setQuantity] = (0,external_react_.useState)(1);
    const [totalPrice, setTotalPrice] = (0,external_react_.useState)(0);
    const [seconds, setSeconds] = (0,external_react_.useState)(38);
    const getContractInformation = async ()=>{
        // Declare provider
        const provider = new external_ethers_.ethers.providers.Web3Provider(window.ethereum, 5);
        // The Contract object
        const contract = new external_ethers_.ethers.Contract(contractAddress, verseshoe, provider);
        // Read max supply
        let maxSupply = await contract.maxSupply();
        //setMaxSupply(parseInt(maxSupply._hex, 16));
        // Read total supply
        let totalSupply = await contract.totalSupply();
        //setTotalSupply(parseInt(totalSupply._hex, 16));
        // Read mint status
        let mintStatus = await contract.currentState();
        setMintStatus(mintStatus);
        // Read max supply
        let maxMintAmountWL = await contract.maxMintAmountWL();
        setMaxMintWhitelist(parseInt(maxMintAmountWL._hex, 16));
        // Initialize quantity
        if (mintStatus == 1) {
            setQuantity(maxMintAmountWL);
        } else {
            setQuantity(1);
        }
        // Read mint price whitelist
        let mintPriceWhitelist = await contract.costWL();
        setMintPriceWhitelist(parseInt(mintPriceWhitelist._hex, 16) / 1000000000000000000);
    };
    const mint = async ()=>{
        // Declare provider
        const provider = new external_ethers_.ethers.providers.Web3Provider(window.ethereum, 5);
        const signer = provider.getSigner();
        const signerAddressLocal = await signer.getAddress();
        // Search in the Whitelist file
        let proof = await getProof(signerAddressLocal.toLocaleLowerCase());
        if (proof == null) {
            onNotify("You are not on the Whitelist!");
        } else {
            // The Contract object
            const contract = new external_ethers_.ethers.Contract(contractAddress, verseshoe, signer);
            // Mint NFT
            const options = {
                value: external_ethers_.ethers.utils.parseEther(totalPrice.toString())
            };
            try {
                await contract.mint(quantity, proof, options);
            } catch (error1) {
                try {
                    onNotify(await error1.error.message.replace("execution reverted: ", ""));
                } catch (error) {
                    onNotify("Transaction aborted!");
                }
            }
        }
    };
    async function getProof(address) {
        // Generate MerkleTree and LeafNodes
        const leafNodes = whitelist.map((addr)=>keccak256(addr));
        const merkleTree = new external_merkletreejs_.MerkleTree(leafNodes, keccak256, {
            sortPairs: true
        });
        let index = whitelist.findIndex((item)=>item.toLocaleLowerCase() == address.toLocaleLowerCase());
        if (index == -1) {
            return null;
        } else {
            return merkleTree.getHexProof(leafNodes[index]);
        }
    }
    // Calls Metamask to connect wallet on clicking Connect Wallet button
    const connectWallet = async ()=>{
        if (window.ethereum) {
            try {
                const provider = new external_ethers_.ethers.providers.Web3Provider(window.ethereum);
                await provider.send("eth_requestAccounts", []);
                const signer = await provider.getSigner(0);
                if (signer === undefined) {
                    dispatch((0,counterSlice/* updateSignerAddress */.Hq)("0"));
                } else {
                    dispatch((0,counterSlice/* updateSignerAddress */.Hq)(await signer.getAddress()));
                }
            } catch (error) {
                onNotify("Error connecting to Metamask!");
            }
        } else {
            onNotify("Metamask isn't installed!");
        }
    };
    const decrement = ()=>{
        let value = quantity;
        if (quantity > 1) {
            setQuantity(--value);
        }
    };
    const increment = ()=>{
        let value = quantity;
        let maxQuantity = maxMintWhitelist;
        if (quantity < maxQuantity) {
            setQuantity(++value);
        }
    };
    (0,external_react_.useEffect)(()=>{
        async function fetchData() {
            if (!window.ethereum) {
                onNotify("Metamask is not detected!");
                return;
            }
            let chainId = await ethereum.request({
                method: "eth_chainId"
            });
            if (parseInt(chainId, 16) !== 5) {
                onNotify("You are not connected to the Mainnet!");
            } else {
                getContractInformation();
            }
        }
        fetchData();
    }, [
        onNotify
    ]);
    (0,external_react_.useEffect)(()=>{
        if (mintStatus == 0) {
            setTotalPrice(0);
        } else {
            setTotalPrice(quantity * mintPriceWhitelist);
        }
    }, [
        mintPriceWhitelist,
        mintStatus,
        quantity
    ]);
    (0,external_react_.useEffect)(()=>{
        const timer = setInterval(()=>{
            if (totalSupply < 2788) {
                setTotalSupply(totalSupply + 1);
            } else {
                setTotalSupply(1188);
            }
        }, 1500);
        return ()=>clearInterval(timer);
    }, [
        totalSupply
    ]);
    (0,external_react_.useEffect)(()=>{
        const timer = setInterval(()=>{
            if (seconds > 0) {
                setSeconds(seconds - 1);
            }
        }, 1000);
        return ()=>clearInterval(timer);
    }, [
        seconds
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "relative pb-10 pt-20 md:pt-31 min-h-screen overflow-x-hidden",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("picture", {
                    className: "pointer-events-none absolute inset-x-0 top-0 -z-10 block h-full",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/images/background.png",
                        alt: "gradient dark",
                        className: "object-cover h-full w-full"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "pt-14 text-center relative text-white font-capture w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-3xl",
                            children: "Mint your"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-6xl",
                            children: "VS Character"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "absolute inset-0 z-10 h-full w-full bg-black opacity-20"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "container h-full mx-auto z-30 relative",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "pt-10 flex justify-center items-center w-full",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "bg-white/20 vs-layer shadow-2xl max-w-5xl relative w-full text-white",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "bg-a-black/20 w-20 h-10 absolute -top-6 -translate-x-1/2 left-1/2"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: " pb-8 flex flex-col p-4 w-full",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "mx-auto text-center space-y-6 w-full",
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "w-full pt-10 pl-10 pr-10 flex text-center",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "border-b border-white w-full self-center"
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                            className: "text-3xl w-full font-bold uppercase pl-4 pr-4",
                                                            children: [
                                                                totalSupply,
                                                                " out of ",
                                                                maxSupply
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "border-b border-white w-full self-center"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "w-full pl-10 pr-10 pb-5",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: "mb-4 w-full h-4 vs-progess-bar-total",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            className: "h-4 vs-progess-bar-fill",
                                                            style: {
                                                                width: totalSupply / maxSupply * 100 + "%"
                                                            }
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "pb-5 text-center text-white font-display text-6xl w-full",
                                                    children: [
                                                        "Hurry up! Mint close in ",
                                                        seconds,
                                                        " seconds!"
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex justify-between text-lg xl:text-xl items-center pb-2 pt-6",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "flex flex-row justify-center h-10 rounded-lg relative bg-transparent mt-1 w-full",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "minus font-capture hover:text-white text-4xl self-center cursor-pointer",
                                                                onClick: ()=>{
                                                                    decrement();
                                                                },
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-center",
                                                                    children: "-"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "quantity font-capture text-white text-5xl self-center",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-center grid h-full place-items-center",
                                                                    children: quantity.toString().length < 2 ? "0" + quantity.toString() : quantity
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "plus font-capture hover:text-white text-4xl self-center cursor-pointer",
                                                                onClick: ()=>{
                                                                    increment();
                                                                },
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                    className: "text-center",
                                                                    children: "+"
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "font-display text-center text-xl text-lg pt-6 pb-6",
                                                    children: [
                                                        maxMintWhitelist,
                                                        " NFT(s) per wallet"
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        signerAddress == "0" ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full mt-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row justify-center w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "vs-button-border"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "vs-button flex cursor-pointer",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "font-display text-white text-lg w-full self-center text-center",
                                            onClick: ()=>{
                                                connectWallet();
                                            },
                                            children: "Connect Wallet"
                                        })
                                    })
                                ]
                            })
                        }) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-full mt-6",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row justify-center w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "vs-button-border"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "vs-button flex cursor-pointer",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "font-display text-white text-lg w-full self-center text-center",
                                            onClick: ()=>{
                                                mint();
                                            },
                                            children: "Mint now"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const mint = (Mint);

// EXTERNAL MODULE: external "react-type-animation"
var external_react_type_animation_ = __webpack_require__(4306);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/intro.jsx




const Intro = ({ onMint  })=>{
    const [isWritten, setWritten] = (0,external_react_.useState)(true);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
            className: "relative pb-10 pt-20 md:pt-31 min-h-screen overflow-x-hidden",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("picture", {
                    className: "pointer-events-none absolute inset-x-0 top-0 -z-10 block h-full",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/images/intro.png",
                        alt: "gradient dark",
                        className: "object-cover h-full w-full"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "relative pt-32 text-white font-capture w-full"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "absolute inset-0 z-10 h-full w-full bg-black opacity-20"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "container h-full mx-auto z-30 relative",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-white text-xl pb-10",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_type_animation_.TypeAnimation, {
                                    sequence: [
                                        "Our community is given the opportunity to win $50,000 and receive Airdrops worth 3-4 ETH from the Verseshoe brand by simply selling VS Characters for a minimum of 2 ETH. It's important to note that even if the listed VS Character is not sold, as long as it is listed above 2 ETH, you will still be eligible for the Airdrop. However, if you do not list the character for at least 2 ETH, you will miss out on the valuable opportunities presented by the Verseshoe brand.",
                                        ()=>{
                                            setWritten(true);
                                        }
                                    ],
                                    wrapper: "p",
                                    cursor: false,
                                    speed: 15
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full mt-6 mb-4",
                                children: isWritten && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    legacyBehavior: true,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-row justify-center w-full fade-in-button",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "vs-button-border"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "vs-button flex cursor-pointer",
                                                onClick: ()=>onMint(),
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    className: "font-display text-white w-full self-center text-center text-lg",
                                                    children: "Go to Mint"
                                                })
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const intro = (Intro);

;// CONCATENATED MODULE: ./pages/home.jsx







const Home = ({ onNotify  })=>{
    const { isMint  } = (0,external_react_redux_.useSelector)((state)=>state.counter);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const enableMint = ()=>{
        dispatch((0,counterSlice/* setMint */.eT)());
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(meta/* default */.Z, {}),
            isMint ? /*#__PURE__*/ jsx_runtime_.jsx(mint, {
                onNotify: onNotify
            }) : /*#__PURE__*/ jsx_runtime_.jsx(intro, {
                onMint: enableMint
            })
        ]
    });
};
/* harmony default export */ const home = (Home);


/***/ })

};
;