"use strict";
exports.id = 954;
exports.ids = [954];
exports.modules = {

/***/ 4954:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Hq": () => (/* binding */ updateSignerAddress),
/* harmony export */   "Tu": () => (/* binding */ closeMblMenu),
/* harmony export */   "VS": () => (/* binding */ openMblMenu),
/* harmony export */   "Wj": () => (/* binding */ popupModalHide),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "eT": () => (/* binding */ setMint)
/* harmony export */ });
/* unused harmony exports counterSlice, isMint, popupModal */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    mblMenu: false,
    popupModal: false,
    isMint: false,
    signerAddress: "0"
};
const counterSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "counter",
    initialState,
    reducers: {
        openMblMenu: (state)=>{
            state.mblMenu = true;
        },
        closeMblMenu: (state)=>{
            state.mblMenu = false;
        },
        popupModalHide: (state, action)=>{
            state.popupModal = false;
        },
        setMint: (state, action)=>{
            state.isMint = true;
        },
        updateSignerAddress: (state, action)=>{
            state.signerAddress = action.payload;
        }
    }
});
// Action creators are generated for each case reducer function
const { openMblMenu , closeMblMenu , isMint , popupModal , popupModalHide , setMint , updateSignerAddress  } = counterSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (counterSlice.reducer);


/***/ })

};
;