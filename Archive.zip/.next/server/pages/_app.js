(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 718:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/tippy.js/dist/tippy.css
var tippy = __webpack_require__(8933);
// EXTERNAL MODULE: ./redux/counterSlice.js
var counterSlice = __webpack_require__(4954);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: external "next/router"
const router_namespaceObject = require("next/router");
;// CONCATENATED MODULE: ./components/mblNavbar.jsx







const MblNavbar = ({ onConnect  })=>{
    const { mblMenu , signerAddress  } = (0,external_react_redux_.useSelector)((state)=>state.counter);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const router = (0,router_namespaceObject.useRouter)();
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("resize", ()=>{
            if (window.innerWidth >= 1024) {
                dispatch((0,counterSlice/* closeMblMenu */.Tu)());
            }
        });
    }, [
        dispatch,
        router
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: mblMenu ? "js-mobile-menu invisible fixed inset-0 z-50 ml-auto items-center bg-black opacity-0 lg:visible lg:relative lg:inset-auto lg:flex lg:bg-transparent lg:opacity-100 nav-menu--is-open" : "js-mobile-menu invisible fixed inset-0 z-50 ml-auto items-center bg-black opacity-0 lg:visible lg:relative lg:inset-auto lg:flex lg:bg-transparent lg:opacity-100 ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "t-0 bg-black fixed left-0 z-50 flex w-full items-center justify-between p-6 lg:hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/",
                        legacyBehavior: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/logo.svg",
                                className: "max-h-7",
                                alt: "Verseshoe | Mint"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "js-mobile-close border-jacarta-100 hover:bg-black focus:bg-black group ml-2 flex h-10 w-10 items-center justify-center rounded-full border transition-colors hover:border-transparent focus:border-transparent border-transparent bg-white/[.15]",
                        onClick: ()=>dispatch((0,counterSlice/* closeMblMenu */.Tu)()),
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            width: "24",
                            height: "24",
                            className: "fill-white h-4 w-4 transition-colors group-hover:fill-white group-focus:fill-white",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    fill: "none",
                                    d: "M0 0h24v24H0z"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M12 10.586l4.95-4.95 1.414 1.414-4.95 4.95 4.95 4.95-1.414 1.414-4.95-4.95-4.95 4.95-1.414-1.414 4.95-4.95-4.95-4.95L7.05 5.636z"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "relative mt-16 mb-8 w-full lg:hidden"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: "navbar w-full !z-50 relative",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "flex flex-col lg:flex-row",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "ml-4 pt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://twitter.com/Verseshoe",
                                legacyBehavior: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "group",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "social flex cursor-pointer",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-full p-2 m-2 self-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                className: "icon group-hover:fill-white fill-white h-6 w-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                    xlinkHref: `/icons.svg#icon-twitter`
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "ml-4 pt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://verseshoes.net/",
                                legacyBehavior: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "group",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "social flex cursor-pointer",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-full p-2 m-2 self-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                className: "icon group-hover:fill-white fill-white h-6 w-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                    xlinkHref: `/icons.svg#icon-world`
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "ml-4 pt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "https://www.instagram.com/verseshoesofficial/",
                                legacyBehavior: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "group",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "social flex cursor-pointer",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "w-full p-2 m-2 self-center",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                className: "icon group-hover:fill-white fill-white h-6 w-6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("use", {
                                                    xlinkHref: `/icons.svg#icon-instagram`
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mt-10 w-full lg:hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                        className: "bg-jacarta-600 my-5 h-px border-0"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex items-center justify-center space-x-5"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "ml-8 hidden lg:flex xl:ml-12"
            })
        ]
    });
};
/* harmony default export */ const mblNavbar = (MblNavbar);

;// CONCATENATED MODULE: ./components/navbar.jsx
/* eslint-disable @next/next/no-img-element */ 






const Navbar = ({ onConnect  })=>{
    const [scroll, setScroll] = (0,external_react_.useState)(false);
    const { mblMenu , isMint  } = (0,external_react_redux_.useSelector)((state)=>state.counter);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const handleSticky = function() {
        if (window.scrollY >= 100) {
            setScroll(true);
        } else {
            setScroll(false);
        }
    };
    const router = (0,router_namespaceObject.useRouter)();
    const pid = router.asPath;
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", handleSticky);
    }, []);
    if (mblMenu) {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: scroll ? "js-page-header fixed top-0 z-50 w-full backdrop-blur transition-colors js-page-header--is-sticky h-full" : "js-page-header fixed top-0 z-50 w-full backdrop-blur transition-colors h-full",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center px-6 py-6 xl:px-24 ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "shrink-0 block",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/images/logo.svg",
                                    alt: "",
                                    className: "max-h-7 h-auto"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(mblNavbar, {
                            onConnect: onConnect
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "ml-auto flex lg:hidden",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/",
                                    legacyBehavior: true,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        className: "border-a-black hover:bg-accent focus:bg-accent group ml-2 flex h-10 w-10 items-center justify-center rounded-full border transition-colors hover:border-transparent focus:border-transparent border-transparent bg-white/[.15]",
                                        "aria-label": "profile",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                            xmlns: "http://www.w3.org/2000/svg",
                                            viewBox: "0 0 24 24",
                                            width: "24",
                                            height: "24",
                                            className: "fill-a-black h-4 w-4 transition-colors group-hover:fill-a-black group-focus:fill-a-black",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    fill: "none",
                                                    d: "M0 0h24v24H0z"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M11 14.062V20h2v-5.938c3.946.492 7 3.858 7 7.938H4a8.001 8.001 0 0 1 7-7.938zM12 13c-3.315 0-6-2.685-6-6s2.685-6 6-6 6 2.685 6 6-2.685 6-6 6z"
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: "js-mobile-toggle border-a-black hover:bg-accent focus:bg-accent group ml-2 flex h-10 w-10 items-center justify-center rounded-full border transition-colors hover:border-transparent focus:border-transparent border-transparent bg-white/[.15]",
                                    "aria-label": "open mobile menu",
                                    onClick: ()=>dispatch((0,counterSlice/* openMblMenu */.VS)()),
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                        xmlns: "http://www.w3.org/2000/svg",
                                        viewBox: "0 0 24 24",
                                        width: "24",
                                        height: "24",
                                        className: "fill-a-black h-4 w-4 transition-colors group-hover:fill-a-black group-focus:fill-a-black",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                fill: "none",
                                                d: "M0 0h24v24H0z"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                d: "M18 18v2H6v-2h12zm3-7v2H3v-2h18zm-3-7v2H6V4h12z"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        });
    } else {
        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/ jsx_runtime_.jsx("header", {
                className: scroll ? "js-page-header page-header--transparent fixed top-0 z-50 w-full bg-white/[.15] transition-colors js-page-header--is-sticky" : scroll ? "js-page-header fixed top-0 z-50 w-full backdrop-blur transition-colors js-page-header--is-sticky" : "js-page-header fixed top-0 z-50 w-full transition-colors",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex items-center px-6 py-6 xl:px-24",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "shrink-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/images/logo.png",
                                    alt: "",
                                    className: isMint ? "w-24 h-auto" : "w-40 h-auto"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(mblNavbar, {
                            onConnect: onConnect
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "ml-auto flex lg:hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "js-mobile-toggle border-a-black hover:bg-black group ml-2 flex h-10 w-10 items-center justify-center rounded-full border transition-colors hover:border-transparent focus:border-transparent border-transparent bg-white/[.15]",
                                "aria-label": "open mobile menu",
                                onClick: ()=>{
                                    dispatch((0,counterSlice/* openMblMenu */.VS)());
                                },
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    viewBox: "0 0 24 24",
                                    width: "24",
                                    height: "24",
                                    className: "fill-white h-4 w-4 transition-colors group-hover:fill-a-black group-focus:fill-a-black",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fill: "none",
                                            d: "M0 0h24v24H0z"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            d: "M18 18v2H6v-2h12zm3-7v2H3v-2h18zm-3-7v2H6V4h12z"
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                })
            })
        });
    }
};
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./components/footer.jsx



const footer = ()=>{
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsx("footer", {
            className: "bg-black page-footer",
            children: /*#__PURE__*/ _jsx("div", {
                className: "container",
                children: /*#__PURE__*/ _jsx("div", {
                    className: "grid grid-cols-6 gap-x-7 gap-y-14 pt-12 pb-12 md:grid-cols-12",
                    children: /*#__PURE__*/ _jsx("div", {
                        className: "col-span-3 md:col-span-4",
                        children: /*#__PURE__*/ _jsx("div", {
                            className: "flex space-x-5",
                            children: /*#__PURE__*/ _jsx(Link, {
                                href: "https://twitter.com/Verseshoe",
                                legacyBehavior: true,
                                children: /*#__PURE__*/ _jsx("a", {
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "group cursor-pointer",
                                    children: /*#__PURE__*/ _jsx("svg", {
                                        className: "icon group-hover:fill-black fill-black h-5 w-5",
                                        children: /*#__PURE__*/ _jsx("use", {
                                            xlinkHref: `/icons.svg#icon-twitter`
                                        })
                                    })
                                })
                            })
                        })
                    })
                })
            })
        })
    });
};
/* harmony default export */ const components_footer = ((/* unused pure expression or super */ null && (footer)));

// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
// EXTERNAL MODULE: external "react-type-animation"
var external_react_type_animation_ = __webpack_require__(4306);
;// CONCATENATED MODULE: ./components/popupModal.jsx





const PopupModal = ()=>{
    const [isWritten, setWritten] = (0,external_react_.useState)(false);
    const [seconds, setSeconds] = (0,external_react_.useState)(38);
    const { popupModal  } = (0,external_react_redux_.useSelector)((state)=>state.counter);
    const dispatch = (0,external_react_redux_.useDispatch)();
    (0,external_react_.useEffect)(()=>{
        if (isWritten) {
            const timer = setInterval(()=>{
                if (seconds > 0) {
                    setSeconds(seconds - 1);
                }
            }, 1000);
            return ()=>clearInterval(timer);
        }
    }, [
        isWritten,
        seconds
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: popupModal ? "block modal fade show " : "modal fade hidden",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "modal-dialog w-10/12",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "modal-content popup text-lg",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-body p-6 pt-14",
                        children: [
                            isWritten && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "pb-10 text-center text-red font-display text-5xl fade-in-button",
                                children: [
                                    "Hurry up! Mint close in ",
                                    seconds,
                                    " seconds!"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-center text-white pl-10 pr-10 pb-10",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_type_animation_.TypeAnimation, {
                                    sequence: [
                                        "We allow our community to win 50k $ and Airdrops worth 3- 4 ETH from the Verseshoe brand simply by selling VS Characters over 2 ETH. Remember that you will still have chance to receive an Airdrop if you listed the VS Character above 2 ETH or more but couldn't sell it. If you do not list it over 2 ETH, you will miss many significant opportunities from the Verseshoe brand.",
                                        ()=>{
                                            setWritten(true);
                                        }
                                    ],
                                    wrapper: "p",
                                    cursor: false,
                                    speed: 35
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full mt-6 mb-4",
                                children: isWritten && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row justify-center w-full fade-in-button",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "vs-button-border"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "vs-button flex cursor-pointer",
                                            onClick: ()=>dispatch((0,counterSlice/* popupModalHide */.Wj)()),
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "font-display text-white w-full self-center text-center text-xl",
                                                children: "Close"
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const popupModal = (PopupModal);

;// CONCATENATED MODULE: ./components/layout.js








function Layout({ children , onNotify  }) {
    const dispatch = (0,external_react_redux_.useDispatch)();
    // Detect change in Metamask account
    (0,external_react_.useEffect)(()=>{
        if (window.ethereum) {
            window.ethereum.on("accountsChanged", (accounts)=>{
                const account = accounts.length > 0 ? accounts[0] : "0";
                dispatch((0,counterSlice/* updateSignerAddress */.Hq)(account));
            });
        }
    });
    // Calls Metamask to connect wallet on clicking Connect Wallet button
    const connectWallet = async ()=>{
        if (window.ethereum) {
            try {
                const provider = new external_ethers_.ethers.providers.Web3Provider(window.ethereum);
                await provider.send("eth_requestAccounts", []);
                const signer = await provider.getSigner(0);
                if (signer === undefined) {
                    dispatch((0,counterSlice/* updateSignerAddress */.Hq)("0"));
                } else {
                    dispatch((0,counterSlice/* updateSignerAddress */.Hq)(await signer.getAddress()));
                }
            } catch (error) {
                onNotify("Error connecting to Metamask!");
            }
        } else {
            onNotify("Metamask isn't installed!");
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {
                onConnect: connectWallet
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(popupModal, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            })
        ]
    });
}


/***/ }),

/***/ 8484:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(718);
/* harmony import */ var _components_meta__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5509);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _redux_store__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5858);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3590);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_toastify__WEBPACK_IMPORTED_MODULE_6__]);
react_toastify__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function MyApp({ Component , pageProps  }) {
    const notify = (message)=>{
        react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            theme: "colored"
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_meta__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_redux__WEBPACK_IMPORTED_MODULE_4__.Provider, {
                store: _redux_store__WEBPACK_IMPORTED_MODULE_5__/* .store */ .h,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        onNotify: notify,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                            ...pageProps,
                            onNotify: notify
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_6__.ToastContainer, {
                        position: "top-right",
                        autoClose: 5000,
                        hideProgressBar: false,
                        newestOnTop: true,
                        closeOnClick: true,
                        rtl: false,
                        pauseOnFocusLoss: true,
                        draggable: true,
                        pauseOnHover: true,
                        theme: "colored"
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _counterSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4954);


const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        counter: _counterSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP
    }
});


/***/ }),

/***/ 8819:
/***/ (() => {



/***/ }),

/***/ 8933:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 1982:
/***/ ((module) => {

"use strict";
module.exports = require("ethers");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 4306:
/***/ ((module) => {

"use strict";
module.exports = require("react-type-animation");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 3590:
/***/ ((module) => {

"use strict";
module.exports = import("react-toastify");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [210,676,664,509,954], () => (__webpack_exec__(8484)));
module.exports = __webpack_exports__;

})();