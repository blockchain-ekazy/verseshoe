import Landing from "./home";

export default function Home({ onNotify }) {
  return (
    <div>
      <Landing onNotify={onNotify} />
    </div>
  );
}
